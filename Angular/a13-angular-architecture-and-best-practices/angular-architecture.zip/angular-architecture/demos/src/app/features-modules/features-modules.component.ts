import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-features-modules',
  templateUrl: './features-modules.component.html',
  styleUrls: [ './features-modules.component.css' ]
})
export class FeaturesModulesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
