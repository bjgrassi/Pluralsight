export enum Theme {
    Light,
    Dark
  }
  
  export enum SidebarPosition {
    Left,
    Right
  }