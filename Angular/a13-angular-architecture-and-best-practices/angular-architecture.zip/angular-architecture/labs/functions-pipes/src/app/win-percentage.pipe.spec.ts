import { WinPercentagePipe } from './win-percentage.pipe';

describe('WinPercentagePipe', () => {
  it('create an instance', () => {
    const pipe = new WinPercentagePipe();
    expect(pipe).toBeTruthy();
  });
});
