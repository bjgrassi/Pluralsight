export const environment = {
  production: true,
  API: "api"
};
