export class Hero {
  id: string;
  name: string;
  description: string;
}
